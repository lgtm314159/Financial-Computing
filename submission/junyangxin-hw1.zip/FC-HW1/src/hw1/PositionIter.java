package hw1;

public interface PositionIter {
  // This method returns the next Position in the bag and null if we've already
  // iterated over all the position
  public Position getNextPosition();
}

