package hw1;

public interface Position {
  public int getQuantity();
  public String getSymbol();
}

